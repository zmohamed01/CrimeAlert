class Report < ApplicationRecord
end
